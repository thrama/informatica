# START/STOP INFORMATICA SERVICES

## ABOUT THE PROJECT
Bash scripts to start and stop the following Informatica DDM product:
- [Dynamic Data Masking](ddm/README.md);
- [Axon](axon/README.md);
- [PowerCenter, TDM, DEI and EDC (with one and multiple Informatica nodes)](pwc/README.md).

The use case is related to the patching install where it is necessary to stop and restart the Informatica products automatically.

## CONTACT
Lorenzo Lombardi - [llombardi@informatica.com](mailto:llombardi@informatica.com)
