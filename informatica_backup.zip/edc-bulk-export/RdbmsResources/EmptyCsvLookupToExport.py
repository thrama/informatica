csvLookupEmpty = [{'createdOn': '', 'objectId': '', 'objectLabel': '',
                   'resourceName': '', 'operation': '', 'chilId': '', 'childLabel': '', 'subType': ''}]
