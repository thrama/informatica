# GENERAL CONFS
infaHome = "/informatica/edc/10.4.1"
resultFolder = "resultFile"

# EMAIL CONFS
smtpHost = ""
sender = ""
smtpAuth = ""
smtpAuthUser = ""
smtpAuthPassword = ""
to = "llombardi@informatica.com"

