csvDatasourceEmpty = [{
                'id':'',
                'name':'',
                'Last Modified':'',
                'GDPR Data Processing note':'',
                'GDPR Data Processing note modifiedby':'',
                'Architectural Level':'',
                'Architectural Level modifiedBy':'',
                'Business Description':'',
                'Business Description modifiedBy':'',
                'Resource Type':'',
                'Resource Name':''
                
                }]
csvDatasetEmpty = [{
                'id':'',
                'Last Modified':'',
                'GDPR Data Processing note':'',
                'GDPR Data Processing note modifiedBy':'',
                'Data Quality Link':'',
                'Data Quality Link modifiedBy':'',
                'Business Description':'',
                'Business Description modifiedBy':'',
                'Resource Name':'',
                'Name':'',
                'DataSource id':''
                }]
csvDataElementEmpty = [{
                'id':'',
                'name':'',
                'Last Modified':'',
                'Key Data Element':'',
                'Key Data Element modifiedBy':'',
                'GDPR Data Processing note':'',
                'GDPR Data Processing note modifiedBy':'',
                'Data Quality Link':'',
                'Data Quality Link modifiedBy':'',
                'Asset Classification':'',
                'Asset Classification modifiedBy':'',
                'Business Description':'',
                'Business Description modifiedBy':'',
                'Resource Name':'',
                'DataSet id':''
                }]
