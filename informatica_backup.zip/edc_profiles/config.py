import os

# GENERAL CONFS
#infaHome = "/informatica/edc/10.4.1"
infaHome = os.environ.get('INFA_HOME')
resultFolder="resultFile"
sheetName="Sheet1"
