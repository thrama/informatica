Data: 19 maggio

Di seguito le variabili definite per la Risorsa:

## DB2 zos

$SourceConnectionName	
$ResourceName	
$UserMetadati	
$PasswordUserMetadati	
$Location
$UserDatiMetadati  			-> servono solo per la Connessione Infa - No EDC
$PasswordUserDatiMetadati	-> servono solo per la Connessione Infa - No EDC
$SubSystemID
$Database  (NEW)
$Ambiente (NEW)	-> Noi non lo usiamo!
$EnableSourceMetadata 	
(REMOVED) $ProfileRunOption	
(REMOVED) $DomainDiscoveryType	
$SamplingOption 	
$RandomSamplingRows	
$ExcludeViews   (NEW)		-> Occhio che è un boolean
$Cumulative 	
(REMOVED) $SelectDataDomain
$DataDomainGroups	-> si possono presentare più valori separati da una virgola (nel JSON devono avere i doppi apici)
$ExcludeNullValues	
$RunSimilarityProfile







