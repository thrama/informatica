Data: 14 Giugno

Di seguito le variabili definite per la Risorsa:

## Teradata

$SourceConnectionName	
$ResourceName	
$UserMetadati	
$PasswordUserMetadati
$UserDatiMetadati  			-> servono solo per la Connessione Infa - No EDC
$PasswordUserDatiMetadati	-> servono solo per la Connessione Infa - No EDC
$FlagConnectString			-> In questo momento non ci serve
$Host	
$ConnectString				-> In questo momento non ci serve
$Database	
$EnableSourceMetadata 	
$SamplingOption 	
$RandomSamplingRows	
$Cumulative 	
$DataDomainGroups	-> si possono presentare più valori separati da una virgola (nel JSON devono avere i doppi apici)
$ExcludeNullValues	
$RunSimilarityProfile

