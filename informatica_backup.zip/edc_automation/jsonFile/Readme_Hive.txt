Data: 22 Giugno

Di seguito le variabili definite per la Risorsa:

## Hive

$SourceConnectionName	
$ResourceName	
$UserMetadati	
$PasswordUserMetadati
$UserDatiMetadati  			-> servono solo per la Connessione Infa - No EDC
$PasswordUserDatiMetadati	-> servono solo per la Connessione Infa - No EDC
$HadoopDistribution	
$HadoopConnection			-> servono solo per la Connessione Infa - No EDC
$URL
$Database
$EnableSourceMetadata 	
$SamplingOption 	
$RandomSamplingRows	
$Cumulative 	
$DataDomainGroups	-> si possono presentare più valori separati da una virgola (nel JSON devono avere i doppi apici)
$ExcludeNullValues	
$RunSimilarityProfile


	
	
	
	


