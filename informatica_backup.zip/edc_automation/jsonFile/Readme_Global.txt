Data: 16 giugno

Di seguito le variabili globali da impostare per tutti i template:

$$domainName
$$disName
$$disUser
$$disPassword
$$disHost
$$disPort
$$disDefault
$$catalogHost
$$catalogPort
$$catalogUser
$$catalogPassword
$$ldapDomain
$$agentURL
$$agentUser
$$agentPassword


Trascodifiche comuni per i campi:

(Per ora nulla)


