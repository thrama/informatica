
SourceConnectionName = <valore>
ResourceName = <valore>	
UserMetadati = <valore>	
PasswordUserMetadati = <valore>
Location = <valore>
SubSystemID = <valore>
[...]

NOTE:
- visto che dobbiamo generare dei file o lanciare dei comandi, io considero i valori come delle stringhe. Per sicurezza, quindi, sarebbe meglio inserirle tra doppi apici (")
- il file deve essere del tipo <nome_file>.py